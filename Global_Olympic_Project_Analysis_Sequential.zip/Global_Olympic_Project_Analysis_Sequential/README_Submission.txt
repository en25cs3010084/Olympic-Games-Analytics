# Global Olympic Project Analysis – Submission Package

Project name: Global Olympic Project Analysis
Prepared: 02 November 2026

This package contains the 28 supplied phase files in sequence. The supplied Problem–Solution Fit sample is retained as reference material. The Team Involvement in Demonstration form is intentionally left blank, as instructed. All other applicable templates have been completed with project-specific information.

## Actual project scope
- 13 country/team records: Australia, China, France, Germany, Great Britain, Hungary, Italy, Japan, Netherlands, ROC, Russia, South Korea, United States.
- Fields: Gold, Silver, Bronze, Total. Total is calculated as Gold + Silver + Bronze.
- Tools actually used: Python, Pandas, Matplotlib and Tableau.
- Tableau dashboard: four views in a 2x2 layout — Gold Medal by Country, Silver Medal by Country, Bronze Medal by Country, Olympic Medal by Country (Total).
- Snowflake and Streamlit were not used. Snowflake-labelled templates are completed as truthful equivalent workflow notes and clearly mark Snowflake-only operations as not applicable.
- No verified GitHub or Tableau Public URL was present in the project materials; no link has been invented.

## Dataset validation summary
- Rows: 13
- Gold sum: 942
- Silver sum: 882
- Bronze sum: 905
- Overall Total: 2,729
- Highest Total: United States (573)
- Lowest Total: Hungary (18)

Dates are aligned to the project phase timeline from October 2026 to 02 November 2026. Team ID is identified as an individual project with no assigned team ID; no fake ID or member names are used.
