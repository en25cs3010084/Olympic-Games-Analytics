import pandas as pd
import matplotlib.pyplot as plt

# Global Olympic medal dataset compiled for this project
df = pd.DataFrame({
    "Country": ["Australia", "China", "France", "Germany", "Great Britain",
                "Hungary", "Italy", "Japan", "Netherlands", "ROC",
                "Russia", "South Korea", "United States"],
    "Gold": [64, 190, 70, 65, 100, 5, 50, 60, 22, 20, 56, 40, 200],
    "Silver": [68, 126, 67, 65, 107, 7, 49, 50, 22, 28, 58, 40, 195],
    "Bronze": [77, 122, 76, 67, 102, 6, 64, 59, 26, 23, 70, 35, 178]
})

# Calculate total medals from the three medal categories
df["Total"] = df["Gold"] + df["Silver"] + df["Bronze"]

# Create the four core country-wise comparison charts
measures = ["Gold", "Silver", "Bronze", "Total"]
for measure in measures:
    plt.figure(figsize=(12, 6))
    plt.bar(df["Country"], df[measure])
    plt.title(f"{measure} Medal by Country" if measure != "Total" else "Olympic Medal by Country")
    plt.xlabel("Country / Team")
    plt.ylabel("Medal Count")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    plt.show()

print(df.to_string(index=False))
